/* Description: Custom JS file */
var myButton=null;
/* Navigation*/
// Collapse the navbar by adding the top-nav-collapse class
window.onscroll = function () {
	myButton= document.getElementById("myBtn");
	scrollFunction();
	scrollFunctionBTT(); // back to top button
};

function scrollFunction() {
	let intViewportWidth = window.innerWidth;
	if (
		document.body.scrollTop > 30 ||
		(document.documentElement.scrollTop > 30) & (intViewportWidth > 991)
	) {
		document.getElementById("navbar").classList.add("top-nav-collapse");
	} else if (
		document.body.scrollTop < 30 ||
		(document.documentElement.scrollTop < 30) & (intViewportWidth > 991)
	) {
		document.getElementById("navbar").classList.remove("top-nav-collapse");
	}
}

// Navbar on mobile
let elements = document.querySelectorAll(".nav-link:not(.dropdown-toggle)");

for (let i = 0; i < elements.length; i++) {
	elements[i].addEventListener("click", () => {
		document.querySelector(".offcanvas-collapse").classList.toggle("open");
	});
}

document.querySelector(".navbar-toggler").addEventListener("click", () => {
	document.querySelector(".offcanvas-collapse").classList.toggle("open");
});

// Hover on desktop
function toggleDropdown(e) {
	const _d = e.target.closest(".dropdown");
	let _m = document.querySelector(".dropdown-menu", _d);

	setTimeout(
		function () {
			const shouldOpen = _d.matches(":hover");
			_m.classList.toggle("show", shouldOpen);
			_d.classList.toggle("show", shouldOpen);

			_d.setAttribute("aria-expanded", shouldOpen);
		},
		e.type === "mouseleave" ? 300 : 0
	);
}

// On hover
document.querySelector(".dropdown").addEventListener("mouseleave", toggleDropdown);

document.querySelector(".dropdown").addEventListener("mouseover", toggleDropdown);

// On click
document.querySelector(".dropdown").addEventListener("click", (e) => {
	const _d = e.target.closest(".dropdown");
	let _m = document.querySelector(".dropdown-menu", _d);
	if (_d.classList.contains("show")) {
		_m.classList.remove("show");
		_d.classList.remove("show");
	} else {
		_m.classList.add("show");
		_d.classList.add("show");
	}
});


/* Card Slider - Swiper */
var cardSlider = new Swiper('.card-slider', {
	autoplay: {
		delay: 4000,
		disableOnInteraction: false
	},
	loop: true,
	navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev'
	}
});




/* Modal Button Close And Scroll To Link */
const theModal = document.getElementById('staticBackdrop');

if (theModal !== null) {
	// Initialize the modal
	const theModalGen = new bootstrap.Modal(theModal);

	// Get the modal button
	const theModalCtaBtn = document.getElementById('modalCtaBtn');

	// Check if the button exists
	if (theModalCtaBtn !== null) {
		// Add event listener to the button
		theModalCtaBtn.addEventListener('click', function () {
			theModalGen.hide();
		});
	} else {
		console.warn('Modal CTA button not found');
	}
} else {
	console.warn('Modal not found');
}


/* Back To Top Button */
// Get the button


// When the user scrolls down 20px from the top of the document, show the button
function scrollFunctionBTT() {
	if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		myButton.style.display = "block";
	} else {
		myButton.style.display = "none";
	}
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
	document.body.scrollTop = 0; // for Safari
	document.documentElement.scrollTop = 0; // for Chrome, Firefox, IE and Opera
}

const interval = setInterval(function () {
	$('.wrapper.search-title').click();
	$('.copyright').remove();
}, 500);

//clearInterval(interval);